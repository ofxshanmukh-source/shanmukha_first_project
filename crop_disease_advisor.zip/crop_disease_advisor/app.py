"""
Streamlit app: Crop Disease Advisory (AI for Social Good).

Run:  streamlit run app.py
Pipeline: photo -> CNN (disease + confidence) -> lesion estimate -> fuzzy severity
          -> rule-based expert system -> advice
If no trained model exists yet the app starts in DEMO MODE so you can test the
reasoning layers by choosing a disease manually.
"""
import json

import pandas as pd
import streamlit as st
from PIL import Image

from src.config import CROP_MODEL_PATH, DISCLAIMER, LOW_CONFIDENCE
from src.expert_system import advice_to_text, advise, load_kb, pretty_class_name
from src.fuzzy_severity import estimate_severity
from src.lesion import estimate_lesion_area
from src.predictor import model_available

st.set_page_config(page_title="Crop Disease Advisor", page_icon="🌿", layout="wide")


@st.cache_resource(show_spinner="Loading model...")
def get_predictor():
    from src.predictor import DiseasePredictor
    return DiseasePredictor()


@st.cache_resource
def get_crop_model():
    from src.crop_recommender import load
    return load()


def all_class_names():
    path = "knowledge_base/classes.txt"
    with open(path, encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]


st.title("🌿 Crop Disease Advisor")
st.caption("AI for Social Good - photo of a leaf in, diagnosis, severity and advice out.")
st.info(DISCLAIMER)

has_model = model_available()
with st.sidebar:
    st.header("Settings")
    demo = st.checkbox("Demo mode (choose the disease manually)", value=not has_model,
                       disabled=not has_model)
    if not has_model:
        st.warning("No trained model found in models/. Run train.py first. Running in demo mode.")
    st.subheader("Field conditions (optional)")
    humidity = st.slider("Relative humidity (%)", 20, 100, 60)
    recent_rain = st.checkbox("Rain in the last 2-3 days")
    st.caption(f"Advice is withheld if model confidence is below {LOW_CONFIDENCE:.0%}.")

tab_diag, tab_crop, tab_about = st.tabs(["Diagnose a leaf", "Crop suggestion", "How it works"])

with tab_diag:
    col1, col2 = st.columns(2)
    with col1:
        source = st.radio("Image source", ["Upload", "Camera"], horizontal=True)
        file = st.file_uploader("Leaf photo", type=["jpg", "jpeg", "png"]) if source == "Upload" \
            else st.camera_input("Take a photo of one leaf")
        img = Image.open(file).convert("RGB") if file else None
        if img is not None:
            st.image(img, caption="Your photo", width=350)

    with col2:
        if img is None:
            st.write("Upload a clear, close-up photo of a single leaf on a plain background.")
        else:
            if demo:
                names = all_class_names()
                chosen = st.selectbox("Pretend the model predicted:", names,
                                      format_func=pretty_class_name)
                conf = st.slider("Simulated model confidence", 0.0, 1.0, 0.92, 0.01)
                top = [(chosen, conf)]
            else:
                top = get_predictor().predict(img, top_k=3)
                chosen, conf = top[0]

            lesion = estimate_lesion_area(img)
            is_healthy = chosen.endswith("___healthy")
            sev = estimate_severity(lesion.area_pct, conf) if not is_healthy else None
            result = advise(chosen, conf, sev["label"] if sev else None,
                            humidity=humidity, recent_rain=recent_rain)

            st.subheader(result["title"])
            m1, m2, m3 = st.columns(3)
            m1.metric("Confidence", f"{conf:.0%}")
            m2.metric("Lesion area (est.)", f"{lesion.area_pct:.0f}%" if lesion.ok else "n/a")
            m3.metric("Severity", sev["label"] if sev else "-")
            if sev:
                st.progress(int(sev["score"]), text=f"Fuzzy severity score {sev['score']}/100")
            if not lesion.ok:
                st.warning("No clear leaf area was detected - use a closer photo on a plain background.")

            if len(top) > 1:
                st.caption("Top predictions")
                st.bar_chart(pd.DataFrame({"confidence": [p for _, p in top]},
                                          index=[pretty_class_name(c) for c, _ in top]))

            for section, text in result["items"]:
                if section in ("Warning", "Urgent"):
                    st.error(f"**{section}:** {text}")
                elif section == "Disclaimer":
                    st.caption(text)
                else:
                    st.markdown(f"**{section}:** {text}")

            with st.expander("Why this advice? (explainability)"):
                st.write("Expert-system rules fired:", ", ".join(result["fired_rules"]))
                if sev:
                    st.write("Fuzzy rules fired:")
                    st.table(pd.DataFrame(sev["fired_rules"]))
                st.image(lesion.overlay, caption="Red = pixels counted as diseased", width=300)

            st.download_button("Download report", advice_to_text(result),
                               file_name="diagnosis_report.txt")

with tab_crop:
    st.write("Optional supervised-ML module: suggest suitable crops from soil and weather values.")
    if not CROP_MODEL_PATH.exists():
        st.info("Train it first:  `python -m src.crop_recommender --csv path/to/Crop_recommendation.csv`")
    else:
        c1, c2, c3, c4 = st.columns(4)
        n = c1.number_input("Nitrogen (N)", 0, 200, 90)
        p = c2.number_input("Phosphorus (P)", 0, 200, 42)
        k = c3.number_input("Potassium (K)", 0, 250, 43)
        ph = c4.number_input("Soil pH", 3.0, 10.0, 6.5)
        t, h, r = st.columns(3)
        temp = t.number_input("Temperature (C)", 0.0, 50.0, 25.0)
        hum = h.number_input("Humidity (%)", 0.0, 100.0, 80.0)
        rain = r.number_input("Rainfall (mm)", 0.0, 400.0, 200.0)
        if st.button("Suggest crops"):
            from src.crop_recommender import recommend
            for crop, prob in recommend(get_crop_model(), n, p, k, temp, hum, ph, rain):
                st.write(f"**{crop}** - {prob:.0%}")

with tab_about:
    st.markdown("""
**Pipeline**
1. **Deep learning + computer vision:** MobileNetV2 (transfer learning) classifies the leaf.
2. **Image analysis:** a colour-based estimator measures how much of the leaf looks diseased.
3. **Fuzzy logic:** lesion area and model confidence are combined into a severity score.
4. **Rule-based expert system:** disease frame + severity + weather give explainable advice.
5. **Classical ML (optional):** Random Forest suggests crops from soil and weather data.

**Limits:** trained mostly on lab-style photos; accuracy drops on real field images; it never
gives pesticide doses. See the README for details.
""")
