# Crop Disease Advisor - AI for Social Good (Capstone Mini Project)

Smallholder farmers often cannot identify crop diseases early. This app takes a **photo of a
leaf** and returns a **diagnosis, a severity level and plain-language advice**, running on a
laptop or free Google Colab with no paid APIs.

## AI concepts integrated (and why)

| # | Concept | Where | Why this choice |
|---|---------|-------|-----------------|
| 1 | Deep learning + computer vision | `train.py`, `src/predictor.py` - MobileNetV2 transfer learning | Strong accuracy with little compute; small enough for CPU inference |
| 2 | Fuzzy logic | `src/fuzzy_severity.py` | Severity is gradual; lesion area and model confidence combine through explainable IF-THEN rules |
| 3 | Rule-based expert system + knowledge representation | `src/expert_system.py`, `knowledge_base/diseases.json` | Advice must be transparent and editable by an agronomist, not a black box |
| 4 | Classical supervised ML (optional) | `src/crop_recommender.py` - Random Forest | Tabular soil/weather data suits tree ensembles; gives a baseline to compare against the CNN |
| 5 | Decision support | `app.py` | Combines all outputs and refuses to advise when confidence is low |

## Pipeline

```
leaf photo -> MobileNetV2 (disease + confidence) -> lesion-area estimate (HSV colour analysis)
          -> fuzzy severity (Low/Medium/High) -> expert-system rules (+ weather facts) -> advice
```

## Quick start (laptop, ~5 minutes, no dataset needed)

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements-core.txt                    # add tensorflow later for training
python -m unittest discover -s tests -t .               # 20 tests should pass
streamlit run app.py                                    # starts in DEMO MODE without a model
```

Demo mode lets you upload any leaf image (try `samples/*.png`, which are synthetic), pick a
disease manually, and watch the fuzzy + expert-system layers work.

## Full run (train the real model)

1. **Get data (free).** Download the original, *non-augmented* PlantVillage colour images from
   Kaggle or TensorFlow Datasets. The Colab notebook shows the Kaggle route. Verify the dataset
   slug and licence on the dataset page yourself.
2. **Split first, augment later** (avoids leakage):
   `python prepare_data.py --src "<folder with class subfolders>" --dst data/split`
3. **Train** (use the Colab T4 GPU: upload the zip and open `notebooks/colab_train.ipynb`):
   `python train.py --data-dir data/split --epochs 6 --finetune-epochs 6`
4. **Evaluate:** `python evaluate.py --data-dir data/split`
   Optional real-field test: download PlantDoc and add `--plantdoc-dir <path>/test`
   (class mapping in `data/plantdoc_class_map.json`; check it against your copy's folder names).
5. **Run the app:** `streamlit run app.py` (needs `models/leaf_model.keras` and `models/class_names.json`).
6. **Optional crop recommender:** download Kaggle "Crop Recommendation Dataset", then
   `python -m src.crop_recommender --csv Crop_recommendation.csv`.

## Project structure

```
app.py                  Streamlit UI (diagnose, crop suggestion, how it works)
prepare_data.py         stratified 70/15/15 split
train.py                two-phase transfer learning (frozen head, then fine-tune)
evaluate.py             accuracy, macro-F1, confusion matrix, latency, PlantDoc test
src/                    config, predictor, lesion, fuzzy_severity, expert_system, crop_recommender
knowledge_base/         diseases.json (26 disease frames), classes.txt (38 PlantVillage classes)
data/plantdoc_class_map.json   PlantDoc -> PlantVillage class mapping (verify)
tests/                  unit tests (fuzzy, lesion, expert system, KB, recommender)
notebooks/colab_train.ipynb    one-click Colab workflow
docs/PROJECT_REPORT.md  report draft with result tables to fill in
```

## Objectives and how to check them

| Objective | Target | How to measure |
|-----------|--------|----------------|
| Classification quality | >= 90% test accuracy, macro-F1 >= 0.85 | `evaluate.py` |
| Real-field robustness | report PlantDoc accuracy and the drop vs. lab images | `evaluate.py --plantdoc-dir` |
| Speed | < 2 s per image on laptop CPU | latency printed by `evaluate.py` |
| Knowledge base | >= 10 diseases, cross-checked with an extension source | `knowledge_base/diseases.json` (26 entries; you must verify them) |
| Usability | test with >= 5 users | see the questionnaire in the report |

## 3-week plan

- **Week 1:** set up, read the dataset, split it, train the baseline, write problem statement and objectives.
- **Week 2:** fine-tune, evaluate (including PlantDoc), tune fuzzy sets, verify knowledge base entries with an extension source.
- **Week 3:** polish the Streamlit UI, run the 5-user test, finish the report and slides, rehearse the demo.

## Limitations and ethics (include these in your report)

- PlantVillage photos are taken in controlled conditions with one plain background, so accuracy on
  farm photos is usually lower. Several photos come from the same leaf, which can still inflate test scores.
- The lesion estimator is a colour heuristic and can be fooled by soil, shadows, flowers or dried leaves.
- The knowledge base is a student summary of general guidance. Have it reviewed by an expert.
- The app gives **no pesticide names or doses** on purpose. Wrong chemical advice can hurt people and the environment.
- Low-confidence predictions are blocked rather than guessed. Say clearly that this is a screening aid.
