"""Generate synthetic leaf images (green ellipse + brown spots) for demos and tests.
These are NOT real photos; they only exercise the lesion estimator and the UI."""
import random
from pathlib import Path

from PIL import Image, ImageDraw


def synthetic_leaf(spot_fraction: float, size: int = 256, seed: int = 0) -> Image.Image:
    rnd = random.Random(seed)
    img = Image.new("RGB", (size, size), (200, 200, 200))        # plain grey background
    d = ImageDraw.Draw(img)
    box = (size * 0.1, size * 0.1, size * 0.9, size * 0.9)
    d.ellipse(box, fill=(40, 140, 50))                            # healthy green leaf
    leaf_area = 3.14159 * (size * 0.4) ** 2
    target, painted = leaf_area * spot_fraction, 0.0
    while painted < target:
        r = rnd.randint(4, 14)
        cx, cy = rnd.randint(int(size * 0.25), int(size * 0.75)), rnd.randint(int(size * 0.25), int(size * 0.75))
        d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=(120, 70, 30))   # brown lesion
        painted += 3.14159 * r * r * 0.6
    return img


if __name__ == "__main__":
    out = Path("samples")
    out.mkdir(exist_ok=True)
    for name, frac in (("synthetic_low", 0.04), ("synthetic_medium", 0.2), ("synthetic_high", 0.5)):
        synthetic_leaf(frac).save(out / f"{name}.png")
    print("wrote samples/*.png (synthetic)")
