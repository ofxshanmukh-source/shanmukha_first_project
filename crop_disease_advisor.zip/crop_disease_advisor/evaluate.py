"""
Evaluate the trained model: accuracy, macro-F1, confusion matrix, inference time,
and (optionally) robustness on real-field PlantDoc images.

  python evaluate.py --data-dir data/split
  python evaluate.py --data-dir data/split --plantdoc-dir path/to/PlantDoc/test
"""
import argparse
import json
import time
from pathlib import Path

import numpy as np
import tensorflow as tf
from PIL import Image
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score

from src.config import CLASS_NAMES_PATH, IMG_SIZE, MODEL_PATH, ROOT

REPORTS = ROOT / "reports"
EXTS = {".jpg", ".jpeg", ".png", ".bmp"}


def plot_confusion(cm, names, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(12, 10))
    ax.imshow(cm, cmap="Blues")
    ax.set_xlabel("Predicted"); ax.set_ylabel("True")
    ax.set_xticks(range(len(names))); ax.set_yticks(range(len(names)))
    ax.set_xticklabels(names, rotation=90, fontsize=5)
    ax.set_yticklabels(names, fontsize=5)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def eval_test_set(model, class_names, data_dir):
    ds = tf.keras.utils.image_dataset_from_directory(
        Path(data_dir) / "test", image_size=(IMG_SIZE, IMG_SIZE), batch_size=32,
        label_mode="int", shuffle=False, class_names=class_names)
    y_true = np.concatenate([y.numpy() for _, y in ds])
    y_pred = np.argmax(model.predict(ds, verbose=0), axis=1)
    acc = accuracy_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred, average="macro")
    print(f"TEST accuracy={acc:.4f}  macro-F1={f1:.4f}")
    print(classification_report(y_true, y_pred, target_names=class_names, zero_division=0))
    plot_confusion(confusion_matrix(y_true, y_pred), class_names, REPORTS / "confusion_matrix.png")
    return {"test_accuracy": float(acc), "test_macro_f1": float(f1), "n_test": int(len(y_true))}


def eval_plantdoc(model, class_names, plantdoc_dir, map_file):
    with open(map_file, encoding="utf-8") as f:
        mapping = {k.lower(): v for k, v in json.load(f).items()}
    y_true, y_pred = [], []
    for folder in sorted(p for p in Path(plantdoc_dir).iterdir() if p.is_dir()):
        target = mapping.get(folder.name.lower())
        if target not in class_names:
            continue
        for f in folder.iterdir():
            if f.suffix.lower() not in EXTS:
                continue
            img = Image.open(f).convert("RGB").resize((IMG_SIZE, IMG_SIZE))
            probs = model.predict(np.asarray(img, dtype="float32")[None], verbose=0)[0]
            y_true.append(class_names.index(target)); y_pred.append(int(np.argmax(probs)))
    if not y_true:
        print("No PlantDoc images matched the class map - check folder names.")
        return {}
    acc = accuracy_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred, average="macro")
    print(f"PLANTDOC (real-field, mapped classes only) accuracy={acc:.4f} macro-F1={f1:.4f} n={len(y_true)}")
    return {"plantdoc_accuracy": float(acc), "plantdoc_macro_f1": float(f1), "n_plantdoc": len(y_true)}


def eval_latency(model, runs=20):
    x = np.random.randint(0, 255, (1, IMG_SIZE, IMG_SIZE, 3)).astype("float32")
    model.predict(x, verbose=0)                       # warm-up
    t = time.perf_counter()
    for _ in range(runs):
        model.predict(x, verbose=0)
    ms = (time.perf_counter() - t) / runs * 1000
    print(f"Average single-image inference: {ms:.0f} ms")
    return {"inference_ms": float(ms)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default="data/split")
    ap.add_argument("--plantdoc-dir", default=None)
    ap.add_argument("--plantdoc-map", default="data/plantdoc_class_map.json")
    args = ap.parse_args()

    REPORTS.mkdir(exist_ok=True)
    model = tf.keras.models.load_model(MODEL_PATH)
    class_names = json.load(open(CLASS_NAMES_PATH, encoding="utf-8"))

    metrics = {}
    metrics.update(eval_test_set(model, class_names, args.data_dir))
    metrics.update(eval_latency(model))
    if args.plantdoc_dir:
        metrics.update(eval_plantdoc(model, class_names, args.plantdoc_dir, args.plantdoc_map))
    with open(REPORTS / "metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)
    print("saved reports/metrics.json")


if __name__ == "__main__":
    main()
