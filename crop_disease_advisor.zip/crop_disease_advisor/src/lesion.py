"""
Simple colour-based lesion estimator (no OpenCV needed, only Pillow + NumPy).

Idea: in HSV space healthy leaf tissue is green; diseased tissue is yellow,
brown or very dark. Lesion % = diseased pixels / (healthy + diseased pixels).
This is a deliberately transparent heuristic, not a trained segmenter - see the
limitations section of the report. It works best on a single leaf on a plain
background.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from PIL import Image


@dataclass
class LesionResult:
    area_pct: float          # % of leaf area that looks diseased
    leaf_fraction: float     # fraction of the image recognised as leaf
    ok: bool                 # False when no leaf-like region was found
    overlay: Image.Image     # original image with diseased pixels tinted red


def estimate_lesion_area(img: Image.Image, max_side: int = 256) -> LesionResult:
    img = img.convert("RGB")
    scale = max_side / max(img.size)
    if scale < 1:
        img = img.resize((max(1, int(img.width * scale)), max(1, int(img.height * scale))))

    hsv = np.asarray(img.convert("HSV")).astype(np.float32)
    h = hsv[..., 0] * 360.0 / 255.0
    s = hsv[..., 1] / 255.0
    v = hsv[..., 2] / 255.0

    green = (h >= 65) & (h <= 170) & (s >= 0.20) & (v >= 0.15)
    yellow_brown = ((h < 65) | (h >= 345)) & (s >= 0.25) & (v >= 0.15)
    dark_necrotic = (v < 0.25) & (s >= 0.20)

    diseased = yellow_brown | dark_necrotic
    leaf = green | diseased

    leaf_fraction = float(leaf.mean())
    n_leaf = int(leaf.sum())
    ok = leaf_fraction >= 0.05 and n_leaf > 0
    area_pct = float(100.0 * diseased.sum() / n_leaf) if ok else 0.0

    arr = np.asarray(img).copy()
    tint = np.array([255, 0, 0], dtype=np.float32)
    arr[diseased] = (0.5 * arr[diseased] + 0.5 * tint).astype(np.uint8)
    return LesionResult(round(area_pct, 1), round(leaf_fraction, 3), ok, Image.fromarray(arr))
