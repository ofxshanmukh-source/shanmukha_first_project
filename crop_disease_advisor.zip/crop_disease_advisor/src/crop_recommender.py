"""
Optional classical-ML component: Random Forest crop recommendation from soil and
weather features (Kaggle 'Crop Recommendation Dataset').

Expected CSV columns: N, P, K, temperature, humidity, ph, rainfall, label
"""
from __future__ import annotations

import argparse
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, f1_score
from sklearn.model_selection import train_test_split

from .config import CROP_MODEL_PATH

FEATURES = ["N", "P", "K", "temperature", "humidity", "ph", "rainfall"]


def train(csv_path: str | Path, out_path: str | Path = CROP_MODEL_PATH, seed: int = 42) -> dict:
    df = pd.read_csv(csv_path)
    X, y = df[FEATURES], df["label"]
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, stratify=y, random_state=seed)
    model = RandomForestClassifier(n_estimators=200, random_state=seed, n_jobs=-1)
    model.fit(X_tr, y_tr)
    pred = model.predict(X_te)
    metrics = {
        "accuracy": float(accuracy_score(y_te, pred)),
        "macro_f1": float(f1_score(y_te, pred, average="macro")),
        "report": classification_report(y_te, pred, output_dict=False),
    }
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, out_path)
    return metrics


def load(path: str | Path = CROP_MODEL_PATH):
    return joblib.load(path)


def recommend(model, n, p, k, temperature, humidity, ph, rainfall, top_k: int = 3) -> list[tuple[str, float]]:
    x = pd.DataFrame([[n, p, k, temperature, humidity, ph, rainfall]], columns=FEATURES)
    proba = model.predict_proba(x)[0]
    idx = np.argsort(proba)[::-1][:top_k]
    return [(str(model.classes_[i]), float(proba[i])) for i in idx]


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Train the crop recommender")
    ap.add_argument("--csv", required=True, help="path to Crop_recommendation.csv")
    args = ap.parse_args()
    m = train(args.csv)
    print(f"accuracy={m['accuracy']:.3f}  macro_f1={m['macro_f1']:.3f}")
    print(m["report"])
