"""Central configuration for the Crop Disease Advisory project."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

IMG_SIZE = 224                      # MobileNetV2 default input size
MODEL_PATH = ROOT / "models" / "leaf_model.keras"
CLASS_NAMES_PATH = ROOT / "models" / "class_names.json"
CROP_MODEL_PATH = ROOT / "models" / "crop_recommender.joblib"
KB_PATH = ROOT / "knowledge_base" / "diseases.json"

# Below this softmax confidence the system refuses to give treatment advice
# and asks the user for a better photo instead.
LOW_CONFIDENCE = 0.60

DISCLAIMER = (
    "This tool gives a first-pass screening only. It cannot replace a trained "
    "agronomist or plant-pathology lab. Product choice and dosage must come from "
    "your local agricultural extension office and the product label."
)
