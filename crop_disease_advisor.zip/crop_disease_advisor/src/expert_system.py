"""
Rule-based expert system (forward chaining) that turns a diagnosis into advice.

Knowledge representation: each disease is a *frame* in knowledge_base/diseases.json
(crop, pathogen type, symptoms, controls, ...). Reasoning knowledge lives in the
RULES list below as IF <condition on facts> THEN <advice>. Every rule that fires is
recorded so the advice is explainable and can be audited by an expert.

Deliberately NOT included: pesticide product names or doses. Those depend on
local regulations and must come from an extension officer or the product label.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Callable

from .config import KB_PATH, LOW_CONFIDENCE, DISCLAIMER

_KB_CACHE: dict | None = None


def load_kb() -> dict:
    global _KB_CACHE
    if _KB_CACHE is None:
        with open(KB_PATH, encoding="utf-8") as f:
            _KB_CACHE = json.load(f)
    return _KB_CACHE


def pretty_class_name(class_name: str) -> str:
    crop, _, cond = class_name.partition("___")
    crop = crop.replace("_", " ").replace(",", "").strip()
    cond = cond.replace("_", " ").strip()
    return f"{crop} - {cond}" if cond else crop


def build_facts(class_name: str, confidence: float, severity_label: str | None,
                humidity: float | None = None, recent_rain: bool = False) -> dict:
    kb = load_kb()
    healthy = class_name.endswith("___healthy")
    entry = kb.get(class_name)
    return {
        "class_name": class_name,
        "healthy": healthy,
        "entry": entry,
        "known": healthy or entry is not None,
        "pathogen_type": "healthy" if healthy else (entry or {}).get("pathogen_type"),
        "fast_spreading": bool((entry or {}).get("fast_spreading", False)),
        "confidence": float(confidence),
        "severity": severity_label,          # 'Low' | 'Medium' | 'High' | None
        "humidity": humidity,                # % relative humidity or None
        "recent_rain": bool(recent_rain),
    }


@dataclass
class Rule:
    name: str
    condition: Callable[[dict], bool]
    action: Callable[[dict], list]           # list of (section, text)
    priority: int = 50                       # lower runs first
    stops_reasoning: bool = False            # stop after this rule fires


def _wet(f):  # humid/wet weather
    return (f["humidity"] is not None and f["humidity"] >= 80) or f["recent_rain"]


RULES: list[Rule] = [
    Rule("R1 low confidence",
         lambda f: f["confidence"] < LOW_CONFIDENCE,
         lambda f: [("Warning", "The model is not confident about this photo. Retake it in daylight: "
                                "one leaf, close up, in focus, plain background. Do not treat or spray "
                                "based on this result.")],
         priority=0, stops_reasoning=True),
    Rule("R2 unknown class",
         lambda f: not f["known"],
         lambda f: [("Warning", "No advice is stored for this class. Ask a local extension officer.")],
         priority=1, stops_reasoning=True),
    Rule("R3 healthy leaf",
         lambda f: f["healthy"],
         lambda f: [("Diagnosis", "The leaf looks healthy."),
                    ("Prevention", "Keep scouting weekly, water at the base of plants, and keep tools clean.")],
         priority=10, stops_reasoning=True),
    Rule("R4 describe disease",
         lambda f: f["entry"] is not None,
         lambda f: [("Diagnosis", f"{f['entry']['name']} ({f['entry']['crop']}). "
                                  f"Typical signs: {f['entry']['symptoms']}"),
                    ("How it spreads", f['entry']['spread'])],
         priority=20),
    Rule("R5 low severity",
         lambda f: f["severity"] == "Low" and f["entry"] is not None,
         lambda f: [("Action", "Damage is still small. Monitor every 2-3 days and start the cultural controls below."),
                    *[("Cultural control", c) for c in f["entry"]["cultural_controls"]]],
         priority=30),
    Rule("R6 medium severity",
         lambda f: f["severity"] == "Medium" and f["entry"] is not None,
         lambda f: [("Action", "Moderate damage. Start the cultural controls now and check nearby plants. "
                               "Ask your local extension officer which locally approved treatment, if any, is suitable."),
                    *[("Cultural control", c) for c in f["entry"]["cultural_controls"]]],
         priority=30),
    Rule("R7 high severity",
         lambda f: f["severity"] == "High" and f["entry"] is not None,
         lambda f: [("Urgent", "Heavy damage. Contact an extension officer or plant clinic as soon as possible and "
                               "isolate or remove the worst-affected plants to protect the rest of the field."),
                    *[("Cultural control", c) for c in f["entry"]["cultural_controls"]]],
         priority=30),
    Rule("R8 fast spreading disease",
         lambda f: f["fast_spreading"] and f["severity"] in ("Medium", "High"),
         lambda f: [("Urgent", "This disease can destroy a crop within days. Act today and warn neighbouring farmers.")],
         priority=31),
    Rule("R9 fungal in wet weather",
         lambda f: f["pathogen_type"] in ("fungal", "oomycete") and _wet(f),
         lambda f: [("Weather risk", "Wet, humid weather speeds up this kind of disease. Avoid overhead watering, "
                                     "improve airflow and scout more often.")],
         priority=40),
    Rule("R10 bacterial",
         lambda f: f["pathogen_type"] == "bacterial",
         lambda f: [("Hygiene", "Do not work among wet plants, and disinfect tools and hands between plants. "
                                "Ask your extension officer whether copper-based products are registered and suitable locally.")],
         priority=40),
    Rule("R11 viral",
         lambda f: f["pathogen_type"] == "viral",
         lambda f: [("Note", "Viral diseases cannot be cured by spraying. Focus on removing infected plants, "
                             "controlling insect vectors and using resistant, clean planting material.")],
         priority=40),
    Rule("R12 pest",
         lambda f: f["pathogen_type"] == "pest",
         lambda f: [("Note", "This is a pest problem, not a fungus. Use integrated pest management and avoid "
                             "broad-spectrum insecticides that kill natural enemies. Ask your extension officer about suitable options.")],
         priority=40),
    Rule("R13 prevention",
         lambda f: f["entry"] is not None,
         lambda f: [("Prevention", p) for p in f["entry"]["prevention"]],
         priority=60),
]


def advise(class_name: str, confidence: float, severity_label: str | None,
           humidity: float | None = None, recent_rain: bool = False) -> dict:
    """Run forward chaining and return structured advice + the rules that fired."""
    facts = build_facts(class_name, confidence, severity_label, humidity, recent_rain)
    items, fired = [], []
    for rule in sorted(RULES, key=lambda r: r.priority):
        if rule.condition(facts):
            fired.append(rule.name)
            items.extend(rule.action(facts))
            if rule.stops_reasoning:
                break
    items.append(("Disclaimer", DISCLAIMER))
    return {"title": pretty_class_name(class_name), "items": items, "fired_rules": fired, "facts": facts}


def advice_to_text(result: dict) -> str:
    lines = [f"Diagnosis report: {result['title']}", "=" * 40]
    for section, text in result["items"]:
        lines.append(f"[{section}] {text}")
    lines.append("")
    lines.append("Rules fired: " + ", ".join(result["fired_rules"]))
    return "\n".join(lines)
