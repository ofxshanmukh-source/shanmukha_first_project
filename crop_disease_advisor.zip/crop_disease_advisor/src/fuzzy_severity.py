"""
Fuzzy-logic severity estimator (Mamdani style, pure Python/NumPy).

Inputs
  * lesion_pct : % of the leaf area that looks diseased (0-100)
  * confidence : CNN softmax confidence for the predicted disease (0-1)
Output
  * severity score 0-100 and a label Low / Medium / High

Why fuzzy logic? "How bad is this leaf?" is a gradual concept. A leaf with 14% vs
16% damage is not suddenly in a different class, and a low-confidence model should
soften (not flip) the conclusion. Fuzzy sets and IF-THEN rules model this directly
and every decision can be explained by the rules that fired.
"""
from __future__ import annotations

import numpy as np


# ---------- membership functions ----------
def trimf(x, a, b, c):
    x = np.asarray(x, dtype=float)
    left = np.where(b != a, (x - a) / (b - a), 1.0)
    right = np.where(c != b, (c - x) / (c - b), 1.0)
    return np.clip(np.minimum(left, right), 0.0, 1.0)


def trapmf(x, a, b, c, d):
    x = np.asarray(x, dtype=float)
    left = np.where(b != a, (x - a) / (b - a), 1.0)
    right = np.where(d != c, (d - x) / (d - c), 1.0)
    return np.clip(np.minimum(np.minimum(left, 1.0), right), 0.0, 1.0)


# ---------- fuzzy sets ----------
def area_sets(x):
    return {
        "low": trapmf(x, -1, 0, 5, 15),
        "medium": trapmf(x, 5, 15, 25, 40),
        "high": trapmf(x, 25, 40, 100, 101),
    }


def conf_sets(x):
    return {
        "low": trapmf(x, -0.01, 0.0, 0.40, 0.65),
        "medium": trimf(x, 0.40, 0.65, 0.85),
        "high": trapmf(x, 0.70, 0.90, 1.0, 1.01),
    }


UNIVERSE = np.arange(0, 101, 1.0)  # severity score axis
SEVERITY_SETS = {
    "low": trapmf(UNIVERSE, -1, 0, 15, 35),
    "medium": trimf(UNIVERSE, 25, 50, 75),
    "high": trapmf(UNIVERSE, 65, 85, 100, 101),
}

# (rule description, consequent)
RULES = [
    ("IF lesion area is LOW THEN severity is LOW", "low"),
    ("IF lesion area is MEDIUM THEN severity is MEDIUM", "medium"),
    ("IF lesion area is HIGH THEN severity is HIGH", "high"),
    ("IF lesion area is HIGH AND confidence is HIGH THEN severity is HIGH", "high"),
    ("IF lesion area is HIGH AND confidence is LOW THEN severity is MEDIUM", "medium"),
    ("IF lesion area is LOW AND confidence is LOW THEN severity is LOW", "low"),
]


def _strengths(area, conf):
    a, c = area_sets(area), conf_sets(conf)
    return [
        float(a["low"]),
        float(a["medium"]),
        float(a["high"]),
        float(min(a["high"], c["high"])),
        float(min(a["high"], c["low"])),
        float(min(a["low"], c["low"])),
    ]


def estimate_severity(lesion_pct: float, confidence: float) -> dict:
    """Return {'score', 'label', 'fired_rules'} for the given crisp inputs."""
    lesion_pct = float(np.clip(lesion_pct, 0, 100))
    confidence = float(np.clip(confidence, 0, 1))
    strengths = _strengths(lesion_pct, confidence)

    aggregated = np.zeros_like(UNIVERSE)
    for (_, consequent), s in zip(RULES, strengths):
        clipped = np.minimum(SEVERITY_SETS[consequent], s)  # Mamdani implication
        aggregated = np.maximum(aggregated, clipped)         # aggregation

    if aggregated.sum() == 0:
        score = 0.0
    else:
        score = float((UNIVERSE * aggregated).sum() / aggregated.sum())  # centroid

    memberships = {k: float(np.interp(score, UNIVERSE, v)) for k, v in SEVERITY_SETS.items()}
    label = max(memberships, key=memberships.get).capitalize()

    fired = [
        {"rule": desc, "strength": round(s, 3)}
        for (desc, _), s in zip(RULES, strengths)
        if s > 0
    ]
    return {"score": round(score, 1), "label": label, "fired_rules": fired}
