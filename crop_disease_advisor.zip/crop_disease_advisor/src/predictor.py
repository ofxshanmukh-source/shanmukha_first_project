"""Loads the trained Keras model and runs top-k prediction on a PIL image."""
from __future__ import annotations

import json

import numpy as np
from PIL import Image

from .config import CLASS_NAMES_PATH, IMG_SIZE, MODEL_PATH


def model_available() -> bool:
    return MODEL_PATH.exists() and CLASS_NAMES_PATH.exists()


class DiseasePredictor:
    def __init__(self, model_path=MODEL_PATH, class_names_path=CLASS_NAMES_PATH):
        import tensorflow as tf  # imported lazily: heavy and only needed here
        self.model = tf.keras.models.load_model(model_path)
        with open(class_names_path, encoding="utf-8") as f:
            self.class_names = json.load(f)

    def predict(self, img: Image.Image, top_k: int = 3) -> list[tuple[str, float]]:
        x = img.convert("RGB").resize((IMG_SIZE, IMG_SIZE))
        # The model contains its own rescaling layer, so raw 0-255 pixels go in.
        arr = np.asarray(x, dtype="float32")[None, ...]
        probs = self.model.predict(arr, verbose=0)[0]
        idx = np.argsort(probs)[::-1][:top_k]
        return [(self.class_names[i], float(probs[i])) for i in idx]
