import unittest

from src.expert_system import advise, load_kb


def sections(res):
    return [s for s, _ in res["items"]]


class ExpertTests(unittest.TestCase):
    def test_low_confidence_withholds_advice(self):
        r = advise("Tomato___Late_blight", 0.30, "High")
        self.assertIn("Warning", sections(r))
        self.assertNotIn("Cultural control", sections(r))
        self.assertEqual(r["fired_rules"], ["R1 low confidence"])

    def test_healthy_leaf(self):
        r = advise("Apple___healthy", 0.95, None)
        self.assertIn("Prevention", sections(r))
        self.assertNotIn("Urgent", sections(r))

    def test_high_severity_is_urgent(self):
        r = advise("Potato___Late_blight", 0.9, "High")
        self.assertIn("Urgent", sections(r))
        self.assertIn("R8 fast spreading disease", r["fired_rules"])

    def test_weather_rule_only_for_fungal_in_wet(self):
        wet = advise("Tomato___Early_blight", 0.9, "Medium", humidity=90)
        dry = advise("Tomato___Early_blight", 0.9, "Medium", humidity=40)
        self.assertIn("R9 fungal in wet weather", wet["fired_rules"])
        self.assertNotIn("R9 fungal in wet weather", dry["fired_rules"])

    def test_viral_has_no_cure_note(self):
        r = advise("Tomato___Tomato_mosaic_virus", 0.9, "Medium")
        self.assertIn("R11 viral", r["fired_rules"])

    def test_no_doses_or_product_names_in_kb(self):
        text = str(load_kb()).lower()
        for banned in (" ml/", "g/l", "mg/", "per litre", "per liter"):
            self.assertNotIn(banned, text)

    def test_disclaimer_always_present(self):
        self.assertIn("Disclaimer", sections(advise("Apple___Apple_scab", 0.9, "Low")))


if __name__ == "__main__":
    unittest.main()
