import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

from src import crop_recommender as cr


class RecommenderTests(unittest.TestCase):
    def test_train_and_recommend_on_synthetic_data(self):
        rng = np.random.default_rng(0)
        rows = []
        for label, centre in (("rice", [80, 40, 40, 25, 80, 6.5, 200]),
                              ("wheat", [100, 50, 30, 18, 60, 7.0, 80])):
            for _ in range(60):
                rows.append(list(np.array(centre) + rng.normal(0, 2, 7)) + [label])
        df = pd.DataFrame(rows, columns=cr.FEATURES + ["label"])
        with tempfile.TemporaryDirectory() as d:
            csv, out = Path(d) / "c.csv", Path(d) / "m.joblib"
            df.to_csv(csv, index=False)
            metrics = cr.train(csv, out)
            self.assertGreater(metrics["accuracy"], 0.9)
            top = cr.recommend(cr.load(out), 80, 40, 40, 25, 80, 6.5, 200)
            self.assertEqual(top[0][0], "rice")


if __name__ == "__main__":
    unittest.main()
