import json
import unittest

from src.config import ROOT
from src.expert_system import load_kb

REQUIRED = {"crop", "name", "pathogen_type", "symptoms", "spread",
            "cultural_controls", "prevention", "fast_spreading"}


class KBTests(unittest.TestCase):
    def setUp(self):
        self.kb = load_kb()
        with open(ROOT / "knowledge_base" / "classes.txt") as fh:
            self.classes = [l.strip() for l in fh if l.strip()]

    def test_every_class_is_covered(self):
        for c in self.classes:
            self.assertTrue(c.endswith("___healthy") or c in self.kb, c)

    def test_entries_are_complete(self):
        for name, e in self.kb.items():
            self.assertTrue(REQUIRED <= set(e), name)
            self.assertTrue(e["cultural_controls"] and e["prevention"], name)

    def test_at_least_ten_diseases(self):
        self.assertGreaterEqual(len(self.kb), 10)

    def test_plantdoc_map_targets_exist(self):
        with open(ROOT / "data" / "plantdoc_class_map.json") as fh:
            m = json.load(fh)
        for target in m.values():
            self.assertIn(target, self.classes)


if __name__ == "__main__":
    unittest.main()
