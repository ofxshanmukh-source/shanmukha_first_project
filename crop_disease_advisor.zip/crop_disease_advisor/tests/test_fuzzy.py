import unittest

from src.fuzzy_severity import estimate_severity


class FuzzyTests(unittest.TestCase):
    def test_labels_at_extremes(self):
        self.assertEqual(estimate_severity(1, 0.95)["label"], "Low")
        self.assertEqual(estimate_severity(20, 0.95)["label"], "Medium")
        self.assertEqual(estimate_severity(70, 0.95)["label"], "High")

    def test_score_monotonic_in_area(self):
        scores = [estimate_severity(a, 0.9)["score"] for a in (0, 5, 15, 30, 60, 90)]
        self.assertEqual(scores, sorted(scores))

    def test_low_confidence_softens_high_area(self):
        hi_conf = estimate_severity(60, 0.95)["score"]
        lo_conf = estimate_severity(60, 0.1)["score"]
        self.assertLess(lo_conf, hi_conf)

    def test_fired_rules_reported(self):
        self.assertTrue(estimate_severity(10, 0.9)["fired_rules"])

    def test_inputs_are_clipped(self):
        r = estimate_severity(500, 7)
        self.assertTrue(0 <= r["score"] <= 100)


if __name__ == "__main__":
    unittest.main()
