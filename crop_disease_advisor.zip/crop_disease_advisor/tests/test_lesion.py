import unittest

from make_samples import synthetic_leaf
from src.lesion import estimate_lesion_area
from PIL import Image


class LesionTests(unittest.TestCase):
    def test_more_spots_means_bigger_area(self):
        areas = [estimate_lesion_area(synthetic_leaf(f)).area_pct for f in (0.02, 0.2, 0.5)]
        self.assertTrue(areas[0] < areas[1] < areas[2], areas)

    def test_clean_leaf_is_near_zero(self):
        self.assertLess(estimate_lesion_area(synthetic_leaf(0.0)).area_pct, 3)

    def test_blank_image_is_flagged(self):
        r = estimate_lesion_area(Image.new("RGB", (100, 100), (200, 200, 200)))
        self.assertFalse(r.ok)
        self.assertEqual(r.area_pct, 0.0)


if __name__ == "__main__":
    unittest.main()
