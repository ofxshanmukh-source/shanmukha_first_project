"""
Create a stratified 70/15/15 train/val/test split from a folder of class subfolders.

IMPORTANT: use the ORIGINAL (non-augmented) images and split BEFORE augmenting.
Splitting an already-augmented dataset puts near-duplicate images in both train and
test and gives inflated accuracy (data leakage). Augmentation in this project is
done on the fly inside the model and only during training.

Usage:
  python prepare_data.py --src "path/to/plantvillage/color" --dst data/split
"""
import argparse
import json
import random
import shutil
from pathlib import Path

from sklearn.model_selection import train_test_split

EXTS = {".jpg", ".jpeg", ".png", ".bmp"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True, help="folder containing one subfolder per class")
    ap.add_argument("--dst", default="data/split")
    ap.add_argument("--val", type=float, default=0.15)
    ap.add_argument("--test", type=float, default=0.15)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    src, dst = Path(args.src), Path(args.dst)
    random.seed(args.seed)
    classes = sorted(p.name for p in src.iterdir() if p.is_dir())
    if not classes:
        raise SystemExit(f"No class folders found in {src}")

    manifest = {}
    for cls in classes:
        files = sorted(p for p in (src / cls).iterdir() if p.suffix.lower() in EXTS)
        if len(files) < 10:
            print(f"skipping {cls}: only {len(files)} images")
            continue
        train_f, rest = train_test_split(files, test_size=args.val + args.test, random_state=args.seed)
        val_f, test_f = train_test_split(rest, test_size=args.test / (args.val + args.test),
                                         random_state=args.seed)
        for split, fl in (("train", train_f), ("val", val_f), ("test", test_f)):
            out = dst / split / cls
            out.mkdir(parents=True, exist_ok=True)
            for f in fl:
                shutil.copy2(f, out / f.name)
        manifest[cls] = {"train": len(train_f), "val": len(val_f), "test": len(test_f)}
        print(f"{cls:60s} train={len(train_f):5d} val={len(val_f):4d} test={len(test_f):4d}")

    dst.mkdir(parents=True, exist_ok=True)
    with open(dst / "split_manifest.json", "w") as f:
        json.dump(manifest, f, indent=2)
    totals = {s: sum(v[s] for v in manifest.values()) for s in ("train", "val", "test")}
    print("totals:", totals)


if __name__ == "__main__":
    main()
