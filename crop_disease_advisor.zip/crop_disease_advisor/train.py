"""
Train a MobileNetV2 transfer-learning classifier (two phases) on the split dataset.

  python train.py --data-dir data/split --epochs 6 --finetune-epochs 6

Outputs: models/leaf_model.keras, models/class_names.json, reports/training_curves.png
"""
import argparse
import json
from pathlib import Path

import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

from src.config import CLASS_NAMES_PATH, IMG_SIZE, MODEL_PATH, ROOT


def load_split(data_dir: Path, split: str, batch: int, shuffle: bool):
    return keras.utils.image_dataset_from_directory(
        data_dir / split, image_size=(IMG_SIZE, IMG_SIZE), batch_size=batch,
        label_mode="int", shuffle=shuffle, seed=42)


def class_weights_from_dirs(train_dir: Path, class_names):
    counts = np.array([len(list((train_dir / c).glob("*"))) for c in class_names], dtype=float)
    weights = counts.sum() / (len(counts) * counts)       # 'balanced' weighting
    return {i: float(w) for i, w in enumerate(weights)}


def build_model(num_classes: int):
    augment = keras.Sequential([
        layers.RandomFlip("horizontal_and_vertical"),
        layers.RandomRotation(0.1),
        layers.RandomZoom(0.1),
        layers.RandomContrast(0.1),
        layers.RandomBrightness(0.1),
    ], name="augmentation")                                # only active during training

    base = keras.applications.MobileNetV2(
        input_shape=(IMG_SIZE, IMG_SIZE, 3), include_top=False, weights="imagenet")
    base.trainable = False

    inputs = keras.Input(shape=(IMG_SIZE, IMG_SIZE, 3))     # raw 0-255 RGB
    x = augment(inputs)
    x = layers.Rescaling(1 / 127.5, offset=-1)(x)           # MobileNetV2 preprocessing
    x = base(x, training=False)
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dropout(0.2)(x)
    outputs = layers.Dense(num_classes, activation="softmax")(x)
    return keras.Model(inputs, outputs), base


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default="data/split")
    ap.add_argument("--epochs", type=int, default=6)
    ap.add_argument("--finetune-epochs", type=int, default=6)
    ap.add_argument("--batch-size", type=int, default=32)
    args = ap.parse_args()

    data_dir = Path(args.data_dir)
    train_ds = load_split(data_dir, "train", args.batch_size, True)
    val_ds = load_split(data_dir, "val", args.batch_size, False)
    class_names = train_ds.class_names
    print(f"{len(class_names)} classes")

    cw = class_weights_from_dirs(data_dir / "train", class_names)
    auto = tf.data.AUTOTUNE
    train_ds, val_ds = train_ds.prefetch(auto), val_ds.prefetch(auto)

    model, base = build_model(len(class_names))
    cbs = [keras.callbacks.EarlyStopping(patience=3, restore_best_weights=True, monitor="val_accuracy")]

    # Phase 1: train only the new classification head
    model.compile(optimizer=keras.optimizers.Adam(1e-3),
                  loss="sparse_categorical_crossentropy", metrics=["accuracy"])
    h1 = model.fit(train_ds, validation_data=val_ds, epochs=args.epochs,
                   class_weight=cw, callbacks=cbs)

    # Phase 2: fine-tune the last 30 layers of the backbone with a small learning rate
    base.trainable = True
    for layer in base.layers[:-30]:
        layer.trainable = False
    model.compile(optimizer=keras.optimizers.Adam(1e-5),
                  loss="sparse_categorical_crossentropy", metrics=["accuracy"])
    h2 = model.fit(train_ds, validation_data=val_ds, epochs=args.finetune_epochs,
                   class_weight=cw, callbacks=cbs)

    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    model.save(MODEL_PATH)
    with open(CLASS_NAMES_PATH, "w", encoding="utf-8") as f:
        json.dump(class_names, f, indent=2)
    print("saved", MODEL_PATH)

    # training curves
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    acc = h1.history["accuracy"] + h2.history["accuracy"]
    val = h1.history["val_accuracy"] + h2.history["val_accuracy"]
    plt.figure(figsize=(6, 4))
    plt.plot(acc, label="train acc")
    plt.plot(val, label="val acc")
    plt.axvline(len(h1.history["accuracy"]) - 1, color="gray", ls="--", label="start fine-tune")
    plt.xlabel("epoch"); plt.ylabel("accuracy"); plt.legend(); plt.tight_layout()
    (ROOT / "reports").mkdir(exist_ok=True)
    plt.savefig(ROOT / "reports" / "training_curves.png", dpi=150)


if __name__ == "__main__":
    main()
