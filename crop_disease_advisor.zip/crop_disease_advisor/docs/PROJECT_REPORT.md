# Artificial Intelligence for Social Good - Crop Disease Advisory
*Capstone mini project report (draft). Replace every `TODO` and verify every cited number.*

## 1. Problem statement
Smallholder farmers often cannot identify crop diseases early. Extension officers are scarce and far
away, so farmers guess, over-spray or lose yield. Affected: small farmers and families, consumers
(food prices) and the environment (pesticide runoff). A phone photo can give an instant first-pass
diagnosis, and a rule layer turns it into cautious advice.

Facts to verify and cite (TODO: confirm figures and add full references):
- FAO/IPPC: pests and diseases cause up to roughly 20-40% of global crop losses annually.
- FAO/IPPC: plant pests cost the global economy on the order of US$200+ billion a year.
- India Agriculture Census 2015-16: about 86% of holdings are small and marginal.

## 2. Objectives and scope
1. >= 90% test accuracy and macro-F1 >= 0.85 on a held-out split.
2. Report PlantDoc (real-field) accuracy and the drop versus lab images.
3. Inference under 2 seconds on a laptop CPU.
4. Knowledge base of >= 10 diseases, cross-checked with an extension source.
5. Usability test with >= 5 users.

Out of scope: pesticide doses, drones or video, all crops, native mobile app, paid APIs.

## 3. Datasets
| Dataset | Use | Notes |
|---|---|---|
| PlantVillage | training / validation / test | lab-condition images, 38 classes; use the non-augmented version |
| PlantDoc | robustness test | real-field images; class map in `data/plantdoc_class_map.json` |
| Crop Recommendation (Kaggle) | optional Random Forest | N, P, K, temperature, humidity, pH, rainfall |

Split: stratified 70/15/15 **before** augmentation (leakage note in README). Augmentation (flip,
rotation, zoom, contrast, brightness) is applied only to training batches inside the model.
Class imbalance handled with balanced class weights.

## 4. System design
```
photo -> MobileNetV2 -> (class, confidence) -+
photo -> lesion estimator -> lesion % --------+-> fuzzy severity -> expert system (+ weather) -> advice
```
**Deep learning / CV:** MobileNetV2 transfer learning (ImageNet weights), frozen head training then
fine-tuning the last 30 layers at lr 1e-5.
**Fuzzy logic:** inputs lesion % and confidence, output severity 0-100; 6 Mamdani rules, centroid
defuzzification. A design lesson worth mentioning: an earlier rule let high confidence raise severity
for medium lesions and made the score non-monotonic in lesion area; unit tests caught it and the rule
was changed to only reinforce high-lesion cases (confidence describes diagnosis certainty, not severity).
**Expert system:** 13 forward-chaining rules over disease frames (knowledge base) and facts
(severity, confidence, humidity, rain). Fired rules are shown to the user.
**Classical ML (optional):** Random Forest crop recommender.
**Safety design:** low-confidence results withhold advice; no product names or doses; disclaimer on every output.

## 5. Results (fill in after running the scripts)
| Metric | Value |
|---|---|
| Test accuracy (PlantVillage split) | TODO |
| Test macro-F1 | TODO |
| PlantDoc accuracy (mapped classes) | TODO |
| Inference time (CPU, ms) | TODO |
| Random Forest crop accuracy (optional) | TODO |

Include `reports/training_curves.png` and `reports/confusion_matrix.png`. Discuss the most confused
classes (for example the three tomato leaf-spot diseases) and the lab-versus-field gap.

## 6. Usability test (>= 5 users)
Ask each user to diagnose 3 leaf photos. Record: task completed (yes/no), time taken, "Was the advice
clear?" (1-5), "Would you trust it?" (1-5), comments. TODO: add the table and a short summary.

## 7. Limitations and ethics
See README. Add: dataset bias towards a few crops, lab-style images, colour-heuristic lesion
estimator, knowledge base not expert-reviewed, risk of over-trust, privacy of uploaded photos
(processed locally, not stored).

## 8. Future work
Grad-CAM explanations, trained lesion segmentation, TFLite model for phones, local-language advice,
voice interface, expert-reviewed knowledge base, field data collection.

## 9. Concept justification (for the viva)
- Why transfer learning? Small compute, strong features, fast convergence.
- Why fuzzy logic and not a threshold? Severity is gradual; fuzzy rules are smooth and explainable.
- Why a rule-based expert system? Auditable, editable by experts, safe (no hallucinated advice).
- Why block low-confidence outputs? A wrong confident treatment is worse than asking for a retake.

## References (TODO: add full citations)
PlantVillage (Hughes & Salathe, 2015); PlantDoc (Singh et al., 2020); MobileNetV2 (Sandler et al., 2018);
FAO/IPPC publications on plant health; your national agriculture census; an agricultural extension guide.
